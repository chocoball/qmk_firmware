#ifndef CONFIG_USER_H
#define CONFIG_USER_H

// if you need more program area, try uncomment follow line
//#include "serial_config_simpleapi.h"

#undef TAPPING_FORCE_HOLD
#undef TAPPING_TERM
#define TAPPING_TERM 120

#endif /* CONFIG_USER_H */
