SSD1306 OLED Display via I2C
======

Features
--------

Some features supported by the firmware:


* I2C connection between the two halves is required as the OLED display will use this connection as well. Note this
  requires pull-up resistors on the data and clock lines.
* OLED display will connect from either side


Wiring
------


Work in progress...


OLED Configuration
-------------------------------

Work in progress...
